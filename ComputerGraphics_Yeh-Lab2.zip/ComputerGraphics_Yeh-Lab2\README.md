# computer-graphic_NCU

## 描述
這是一個小畫家，可以畫直線、多邊形、圓圈、橢圓、曲線、鉛筆以及橡皮擦

### 功能說明
畫長方形
![示範jpg](./image/rec.PNG)
畫星星
![示範jpg](./image/star.PNG)
影片示範
![示範gif](./image/video.gif)



#### 補充
有使用chatgpt協助完成作業，把我打好的程式碼丟給chatgpt請他幫我修改及優化